<?php

//创建websocket服务器对象，监听0.0.0.0:9502端口
$ws = new swoole_websocket_server("192.168.1.120", 9505);

//监听WebSocket连接打开事件
$ws->on('open', function ($ws, $request) {
    $fd[] = $request->fd;
    $GLOBALS['fd'][] = $fd;

    $fd[] = $request->fd;

    $aaa = '当前在线用户 : ';
    foreach($ws->connections as $aa) {
        $aaa .= $aa."   ";
    }

    foreach($ws->connections as $aa) {
        $push_arr = array(
            'type' => 'login',
            'data' => $aaa,
        );
        $ws->push($aa, json_encode($push_arr));
    }
});

$ws->on('message', function ($ws, $frame) {
    $data = json_decode( $frame->data , true );

    if($data['type']==2){
        foreach ($ws->connections as $conn) {
            $content=isset($data['content']) ? $data['content']:'';
            $arr = json_encode(
                array(
                    'type'=>2,
                    'content'=>$content,
                )
            );
            $ws->push($conn, $arr);
        }
    }elseif($data['type']==1){
        foreach ($ws->connections as $conn) {
            $name=isset($data['name']) ? $data['name']:'游客';
            $content = '欢迎' . $name.'加入群聊';
            $arr = json_encode(
                array(
                    'type'=>1,
                    'content'=>$content,
                )
            );
            $ws->push($conn, $arr);
        }
    }elseif($data['type']==3){
        foreach ($ws->connections as $conn) {
            $name=isset($data['name']) ? $data['name']:'';
            $content=isset($data['content']) ? $data['content']:'';
            $content = $name.' "说:"' . $content;
            $arr = json_encode(
                array(
                    'type'=>3,
                    'content'=>$content,
                )
            );
            $ws->push($conn, $arr);
        }
    }elseif($data['type']==4){
        foreach ($ws->connections as $conn) {
            $img=rand(0,3).'.gif';
            $send_msg = 'face/'.$img;
            $arr = json_encode(
                array(
                    'type'=>4,
                    'content'=>$send_msg,
                )
            );
            $ws->push($conn, $arr);
        }
    }elseif($data['type']==6){
        foreach ($ws->connections as $conn) {
            $name=isset($data['name']) ? $data['name']:'';
            $content=isset($data['noticeContent']) ? $data['noticeContent']:'';
            $arr = json_encode(
                array(
                    'type'=>6,
                    'content'=>'['.$name.'发出公告]:'.$content,
                )
            );
            $ws->push($conn, $arr);
        }
    }elseif($data['type']==5) {

        foreach ($ws->connections as $conn) {
            $name = isset($data['name']) ? $data['name'] : '未知用户';
            $content = '[' . $name . ']已退出群聊';
            $arr = json_encode(
                array(
                    'type'=>5,
                    'content'=>$content,
                )
            );
            $ws->push($conn, $arr);
        }
        //关闭当前链接
        $ws->close($data['fd']);
    }

});

//监听WebSocket连接关闭事件
$ws->on('close', function ($ws, $fd) {
    echo "client-{$fd} is closed\n";

    $aaa = '在线用户 : ';
    foreach($ws->connections as $aa) {
        if($fd != $aa) {
            $aaa .= $aa."   ";
        }
    }

    foreach($ws->connections as $aa) {
        $push_arr = array(
            'type' => 'login',
            'data' => $aaa,
        );
        echo $aaa;
        $ws->push($aa, json_encode($push_arr));
    }
});

$ws->start();


?>

